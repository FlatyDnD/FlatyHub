/**
 * FlatyHub
 * Central management hub for future Flaty modules.
 *
 * Public API:
 *   game.flatyHub.registerModule({...})
 *   game.flatyHub.unregisterModule("module-id")
 *   game.flatyHub.open()
 */

const FH = {
  id: "flatyhub",
  version: "0.0.0",
  modules: new Map(),
  app: null,

  registerModule(data = {}) {
    if (!data.id) {
      console.warn("FlatyHub | Module registration rejected: missing id.");
      return false;
    }

    const moduleData = {
      id: String(data.id),
      name: data.name ?? data.id,
      description: data.description ?? "",
      icon: data.icon ?? "fa-solid fa-puzzle-piece",
      version: data.version ?? "",
      category: data.category ?? "Module",
      color: data.color ?? "",
      onOpen: typeof data.onOpen === "function" ? data.onOpen : null,
      onSettings: typeof data.onSettings === "function" ? data.onSettings : null,
      isActive: data.isActive !== false,
      meta: data.meta ?? {}
    };

    this.modules.set(moduleData.id, moduleData);

    if (this.app?.rendered) this.app.render(true);
    return true;
  },

  unregisterModule(id) {
    const removed = this.modules.delete(String(id));
    if (removed && this.app?.rendered) this.app.render(true);
    return removed;
  },

  getModule(id) {
    return this.modules.get(String(id)) ?? null;
  },

  getModules() {
    return [...this.modules.values()];
  },

  getRegisteredModuleIds() {
    return [...this.modules.keys()];
  },

  open() {
    if (!this.app) this.app = new FlatyHubApp();
    this.app._selectedPage = "home";
    this.app.render(true);
  },

  openSettings() {
    if (!this.app) this.app = new FlatyHubApp();
    this.app._selectedPage = "settings";
    this.app.render(true);
  }
};

class FlatyHubApp extends Application {
  constructor(options = {}) {
    super(options);
    this._selectedPage = "home";
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "flatyhub-app",
      title: "FlatyHub",
      width: 1080,
      height: 720,
      resizable: true,
      classes: ["flatyhub-window"]
    });
  }

  getData() {
    const modules = FH.getModules();
    const installed = game.modules.get("flatyhub");
    const version = installed?.version ?? FH.version;
    FH.version = version;

    let accent = "#ff8a24";
    try {
      accent = game.settings.get("flatyhub", "accentColor") || accent;
    } catch (_) {}

    return {
      modules,
      moduleCount: modules.length,
      activeCount: modules.filter(m => m.isActive).length,
      version,
      accent
    };
  }

  activateListeners() {
    // Controls are handled by the capture-phase document listener installed
    // once below. This avoids conflicts with Foundry's Application/window
    // event handling and remains reliable after every innerHTML rebuild.
  }

  _renderInner(data) {
    const modules = data.modules;

    const moduleCards = modules.length
      ? modules.map(mod => `
          <article class="fh-module-card" style="${mod.color ? `--fh-module-accent:${this._escapeAttr(mod.color)};` : ""}">
            <div class="fh-module-icon">
              <i class="${this._escapeAttr(mod.icon)}"></i>
            </div>
            <div class="fh-module-body">
              <div class="fh-module-topline">
                <h3>${this._escapeHtml(mod.name)}</h3>
                <span class="fh-status ${mod.isActive ? "is-active" : "is-inactive"}">
                  <span></span>${mod.isActive ? "Активен" : "Отключён"}
                </span>
              </div>
              <p>${this._escapeHtml(mod.description || "Описание не указано.")}</p>
              <div class="fh-module-meta">
                <span>${this._escapeHtml(mod.category)}</span>
                ${mod.version ? `<span>v${this._escapeHtml(mod.version)}</span>` : ""}
              </div>
            </div>
            <div class="fh-module-actions">
              <button type="button" class="fh-button fh-button-primary" data-fh-module="${this._escapeAttr(mod.id)}">
                <i class="fa-solid fa-arrow-up-right-from-square"></i>
                Открыть
              </button>
              <button type="button" class="fh-button fh-button-ghost" data-fh-hub-settings title="Настройки FlatyHub">
                <i class="fa-solid fa-gear"></i>
              </button>
            </div>
          </article>
        `).join("")
      : `
        <div class="fh-empty">
          <div class="fh-empty-icon"><i class="fa-solid fa-puzzle-piece"></i></div>
          <h2>Модули ещё не подключены</h2>
          <p>FlatyHub готов. Когда мы создадим следующие модули, они смогут автоматически зарегистрироваться здесь.</p>
          <div class="fh-empty-hint">
            <i class="fa-solid fa-circle-info"></i>
            Сейчас это только центральная оболочка.
          </div>
        </div>
      `;

    const managerSettings = `
      <div class="fh-settings-card">
        <button type="button" class="fh-settings-row fh-clickable" data-fh-manager-settings>
          <div class="fh-settings-icon"><i class="fa-solid fa-palette"></i></div>
          <div class="fh-settings-copy">
            <strong>Настройки FlatyHub</strong>
            <p>Цвет акцента и параметры самого центра управления.</p>
          </div>
          <i class="fa-solid fa-chevron-right fh-row-arrow"></i>
        </button>
        <button type="button" class="fh-settings-row fh-clickable" data-fh-keybindings>
          <div class="fh-settings-icon"><i class="fa-solid fa-keyboard"></i></div>
          <div class="fh-settings-copy">
            <strong>Горячая клавиша</strong>
            <p>Нажмите сюда и затем введите любую клавишу или комбинацию для открытия FlatyHub.</p>
          </div>
          <span class="fh-keybadge">${this._escapeHtml(formatFlatyHubBinding())}</span>
          <i class="fa-solid fa-chevron-right fh-row-arrow"></i>
        </button>
      </div>
    `;

    const moduleSettings = modules.length
      ? `
        <div class="fh-settings-group-title">НАСТРОЙКИ МОДУЛЕЙ</div>
        <div class="fh-settings-card">
          ${modules.map(mod => `
            <button type="button" class="fh-settings-row fh-clickable" data-fh-module-settings="${this._escapeAttr(mod.id)}">
              <div class="fh-settings-icon"><i class="${this._escapeAttr(mod.icon)}"></i></div>
              <div class="fh-settings-copy">
                <strong>${this._escapeHtml(mod.name)}</strong>
                <p>${this._escapeHtml(mod.description || "Открыть настройки этого модуля.")}</p>
              </div>
              <span class="fh-status ${mod.isActive ? "is-active" : "is-inactive"}">
                <span></span>${mod.isActive ? "Активен" : "Отключён"}
              </span>
              <i class="fa-solid fa-chevron-right fh-row-arrow"></i>
            </button>
          `).join("")}
        </div>
      `
      : `
        <div class="fh-settings-empty">
          <i class="fa-solid fa-puzzle-piece"></i>
          <span>Совместимых модулей пока нет.</span>
        </div>
      `;

    const content = this._selectedPage === "modules"
      ? `
        <section class="fh-page">
          <div class="fh-page-header">
            <div>
              <div class="fh-eyebrow">FLATYHUB · MODULE MANAGER</div>
              <h2>Модули</h2>
              <p>Модули, которые зарегистрировались в FlatyHub.</p>
            </div>
            <button type="button" class="fh-button fh-button-ghost" data-fh-refresh>
              <i class="fa-solid fa-rotate"></i> Обновить
            </button>
          </div>

          <div class="fh-module-list">
            ${modules.length ? moduleCards : `
              <div class="fh-empty">
                <div class="fh-empty-icon"><i class="fa-solid fa-cubes"></i></div>
                <h2>Модули ещё не подключены</h2>
                <p>Когда мы создадим следующий модуль, он сможет автоматически появиться здесь вместе со своим состоянием и версией.</p>
              </div>
            `}
          </div>
        </section>
      `
      : this._selectedPage === "settings"
      ? `
        <section class="fh-page">
          <div class="fh-page-header">
            <div>
              <div class="fh-eyebrow">FLATYHUB · CONFIGURATION</div>
              <h2>Настройки</h2>
              <p>Управление самим FlatyHub и настройками подключённых модулей.</p>
            </div>
          </div>

          <div class="fh-settings-layout">
            <div>
              <div class="fh-settings-group-title">ЦЕНТР УПРАВЛЕНИЯ</div>
              ${managerSettings}
            </div>
            <div>
              ${moduleSettings}
            </div>
          </div>
        </section>
      `
      : `
        <section class="fh-page">
          <div class="fh-page-header">
            <div>
              <div class="fh-eyebrow">FLATYHUB · CONTROL CENTER</div>
              <h2>Центр управления</h2>
              <p>Единая точка управления модулями Flaty.</p>
            </div>
          </div>

          <div class="fh-stats fh-stats-home">
            <div class="fh-stat">
              <span>МОДУЛЕЙ</span>
              <strong>${data.moduleCount}</strong>
              <small>зарегистрировано</small>
            </div>
            <div class="fh-stat">
              <span>АКТИВНЫХ</span>
              <strong>${data.activeCount}</strong>
              <small>готовы к работе</small>
            </div>
            <div class="fh-stat fh-stat-accent">
              <span>СОСТОЯНИЕ</span>
              <strong>OK</strong>
              <small>система работает</small>
            </div>
          </div>

          <div class="fh-home-panel">
            <div class="fh-home-panel-icon">
              <i class="fa-solid fa-layer-group"></i>
            </div>
            <div>
              <h3>FlatyHub готов к работе</h3>
              <p>Используйте раздел «Модули» для управления подключёнными модулями.</p>
            </div>
          </div>
        </section>
      `



    return `
      <div class="fh-shell" style="--fh-orange:${this._escapeAttr(data.accent)}; --fh-orange-2:${this._escapeAttr(data.accent)};">
        <aside class="fh-sidebar">
          <div class="fh-brand">
            <div class="fh-brand-mark"><i class="fa-solid fa-layer-group"></i></div>
            <div>
              <strong>FLATYHUB</strong>
              <span>CONTROL CENTER</span>
            </div>
          </div>

          <nav class="fh-nav">
            <button type="button" class="fh-nav-item ${this._selectedPage === "home" ? "is-selected" : ""}" data-fh-page="home">
              <i class="fa-solid fa-gauge-high"></i>
              <span>Главная</span>
            </button>
            <button type="button" class="fh-nav-item ${this._selectedPage === "modules" ? "is-selected" : ""}" data-fh-page="modules">
              <i class="fa-solid fa-cubes"></i>
              <span>Модули</span>
              <b>${data.moduleCount}</b>
            </button>
            <button type="button" class="fh-nav-item ${this._selectedPage === "settings" ? "is-selected" : ""}" data-fh-page="settings">
              <i class="fa-solid fa-sliders"></i>
              <span>Настройки</span>
            </button>
          </nav>

          <div class="fh-sidebar-bottom">
            <div class="fh-system">
              <span class="fh-system-dot"></span>
              <div>
                <strong>FlatyHub Online</strong>
                <small>v${this._escapeHtml(data.version)}</small>
              </div>
            </div>
          </div>
        </aside>

        <main class="fh-main">
          <header class="fh-header">
            <div>
              <span class="fh-header-kicker">FLATY · MANAGEMENT SYSTEM</span>
              <h1>FlatyHub</h1>
            </div>
            <div class="fh-header-actions">
              <span class="fh-live"><span></span> SYSTEM ONLINE</span>
            </div>
          </header>

          <div class="fh-content">${content}</div>
        </main>
      </div>
    `;
  }

  async _render(force = false, options = {}) {
    const html = await super._render(force, options);
    const data = this.getData();

    if (!this.element) return html;

    const target = this.element.querySelector?.(".window-content");
    if (!target) return html;

    target.innerHTML = this._renderInner(data);
    target.classList.add("fh-window-content");

    // One listener on the final content element handles all current and future
    // controls. This survives our innerHTML rebuilds and does not depend on
    // Foundry's legacy Application listener lifecycle.
    target.onclick = (event) => {
      const page = event.target.closest?.("[data-fh-page]");
      if (page && target.contains(page)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        this._selectedPage = page.dataset.fhPage;
        void this.render(true);
        return;
      }

      const refresh = event.target.closest?.("[data-fh-refresh]");
      if (refresh && target.contains(refresh)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        void this.render(true);
        return;
      }

      const moduleButton = event.target.closest?.("[data-fh-module]");
      if (moduleButton && target.contains(moduleButton)) {
        event.preventDefault();
        event.stopImmediatePropagation();

        const id = moduleButton.dataset.fhModule;
        const mod = FH.getModule(id);
        if (!mod) return;

        if (typeof mod.onOpen === "function") {
          try {
            mod.onOpen();
          } catch (error) {
            console.error(`FlatyHub | Error opening module "${id}".`, error);
            ui.notifications.error(`FlatyHub: не удалось открыть модуль «${mod.name}».`);
          }
        } else {
          ui.notifications.info(`Модуль «${mod.name}» пока не имеет собственного окна.`);
        }
        return;
      }

      const hubSettingsButton = event.target.closest?.("[data-fh-hub-settings]");
      if (hubSettingsButton && target.contains(hubSettingsButton)) {
        event.preventDefault();
        event.stopImmediatePropagation();
        FH.openSettings();
        return;
      }

      const settingsButton = event.target.closest?.("[data-fh-settings]");
      if (settingsButton && target.contains(settingsButton)) {
        event.preventDefault();
        event.stopImmediatePropagation();

        const id = settingsButton.dataset.fhSettings;
        const mod = FH.getModule(id);
        if (!mod?.onSettings) return;

        try {
          mod.onSettings();
        } catch (error) {
          console.error(`FlatyHub | Error opening settings for "${id}".`, error);
          ui.notifications.error(`FlatyHub: не удалось открыть настройки «${mod.name}».`);
        }
      }
    };

    return html;
  }

  _escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  _escapeAttr(value) {
    return this._escapeHtml(value);
  }
}


function getFlatyHubKeybinding() {
  try {
    const bindings = game.keybindings.get("flatyhub", "openHub") ?? [];
    return bindings[0] ?? { key: "KeyH", modifiers: ["CONTROL", "SHIFT"] };
  } catch (_) {
    return { key: "KeyH", modifiers: ["CONTROL", "SHIFT"] };
  }
}

function formatFlatyHubBinding(binding = getFlatyHubKeybinding()) {
  const modifierNames = {
    CONTROL: "Ctrl",
    ALT: "Alt",
    SHIFT: "Shift",
    META: "Meta"
  };

  const modifiers = (binding.modifiers ?? [])
    .map(mod => modifierNames[mod] ?? mod)
    .filter(Boolean);

  let key = binding.key ?? "";
  const keyNames = {
    Space: "Space",
    Escape: "Esc",
    Enter: "Enter",
    Tab: "Tab",
    Backspace: "Backspace",
    Delete: "Delete",
    ArrowUp: "↑",
    ArrowDown: "↓",
    ArrowLeft: "←",
    ArrowRight: "→",
    NumpadAdd: "Numpad +",
    NumpadSubtract: "Numpad -"
  };

  if (keyNames[key]) key = keyNames[key];
  else if (key.startsWith("Key")) key = key.slice(3);
  else if (key.startsWith("Digit")) key = key.slice(5);
  else if (key.startsWith("Numpad")) key = key.replace("Numpad", "Numpad ");

  return [...modifiers, key].filter(Boolean).join(" + ");
}

function openFlatyHubKeyCapture() {
  if (document.querySelector(".fh-keycapture-backdrop")) return;

  const backdrop = document.createElement("div");
  backdrop.className = "fh-keycapture-backdrop";
  backdrop.innerHTML = `
    <div class="fh-keycapture-dialog" role="dialog" aria-modal="true">
      <div class="fh-keycapture-icon">
        <i class="fa-solid fa-keyboard"></i>
      </div>
      <div class="fh-keycapture-eyebrow">FLATYHUB · KEYBINDING</div>
      <h2>Назначение горячей клавиши</h2>
      <p>Введите клавишу или комбинацию для открытия <strong>FlatyHub</strong>.</p>
      <div class="fh-keycapture-current">
        <span>Текущая горячая клавиша</span>
        <strong>${formatFlatyHubBinding()}</strong>
      </div>
      <div class="fh-keycapture-field" data-fh-keycapture-field>
        <span>Ожидание нажатия…</span>
      </div>
      <div class="fh-keycapture-hint">
        <i class="fa-solid fa-circle-info"></i>
        Например: Ctrl + Shift + H, Alt + F, F8.
      </div>
      <div class="fh-keycapture-actions">
        <button type="button" class="fh-keycapture-cancel" data-fh-keycapture-cancel>Отмена</button>
      </div>
    </div>
  `;

  document.body.appendChild(backdrop);

  const field = backdrop.querySelector("[data-fh-keycapture-field]");
  const cancel = backdrop.querySelector("[data-fh-keycapture-cancel]");
  let finished = false;

  const close = () => {
    if (finished) return;
    finished = true;
    document.removeEventListener("keydown", onKeyDown, true);
    backdrop.remove();
  };

  const onKeyDown = async (event) => {
    if (finished) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    // Escape cancels the capture instead of becoming the new binding.
    if (event.code === "Escape") {
      close();
      return;
    }

    // Ignore modifier-only presses. A real key is required.
    const modifierOnly = ["Control", "Shift", "Alt", "Meta"];
    if (modifierOnly.includes(event.key)) {
      field.classList.add("is-waiting");
      return;
    }

    const modifiers = [];
    if (event.ctrlKey) modifiers.push("CONTROL");
    if (event.altKey) modifiers.push("ALT");
    if (event.shiftKey) modifiers.push("SHIFT");
    if (event.metaKey) modifiers.push("META");

    const binding = {
      key: event.code,
      modifiers
    };

    field.innerHTML = `<i class="fa-solid fa-check"></i><strong>${formatFlatyHubBinding(binding)}</strong>`;
    field.classList.remove("is-waiting");
    field.classList.add("is-saved");

    try {
      // Foundry's ClientKeybindings.set writes the editable binding and
      // immediately updates the active keybinding manager.
      await game.keybindings.set("flatyhub", "openHub", [binding]);
      ui.notifications.info(`Горячая клавиша FlatyHub изменена: ${formatFlatyHubBinding(binding)}`);
      setTimeout(close, 350);
      FH.app?.render(true);
    } catch (error) {
      console.error("FlatyHub | Failed to set keybinding.", error);
      field.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i><strong>Не удалось сохранить</strong>`;
      field.classList.add("is-error");
      ui.notifications.error("FlatyHub: не удалось сохранить горячую клавишу.");
      setTimeout(() => {
        field.innerHTML = "<span>Ожидание нажатия…</span>";
        field.classList.remove("is-error", "is-saved");
      }, 1200);
    }
  };

  cancel.addEventListener("click", close);
  backdrop.addEventListener("click", (event) => {
    if (event.target === backdrop) close();
  });

  document.addEventListener("keydown", onKeyDown, true);
  field.focus?.();
}

function openFlatyHubManagerSettings() {
  const current = (() => {
    try { return game.settings.get("flatyhub", "accentColor") || "#ff8a24"; }
    catch (_) { return "#ff8a24"; }
  })();

  const content = `
    <form class="fh-manager-settings-form">
      <div class="fh-manager-setting">
        <label for="fh-accent-color">Цвет акцента</label>
        <div class="fh-color-control">
          <input id="fh-accent-color" name="accentColor" type="color" value="${current}">
          <span>Используется для подсветки FlatyHub и его интерфейса.</span>
        </div>
      </div>
    </form>
  `;

  const saveAccent = (html) => {
    const color = html.querySelector?.('[name="accentColor"]')?.value
      ?? html.find?.('[name="accentColor"]').val();
    if (color) game.settings.set("flatyhub", "accentColor", color);
  };

  if (foundry?.applications?.api?.DialogV2) {
    foundry.applications.api.DialogV2.wait({
      window: { title: "FlatyHub · Настройки" },
      content,
      buttons: [
        {
          action: "save",
          label: "Сохранить",
          icon: "fa-solid fa-check",
          callback: (_event, _button, dialog) => {
            const form = dialog?.element?.querySelector?.("form");
            if (form?.elements?.accentColor) {
              game.settings.set("flatyhub", "accentColor", form.elements.accentColor.value);
            }
            FH.app?.render(true);
          }
        },
        {
          action: "cancel",
          label: "Отмена",
          icon: "fa-solid fa-xmark"
        }
      ],
      default: "save"
    });
    return;
  }

  new Dialog({
    title: "FlatyHub · Настройки",
    content,
    buttons: {
      save: {
        icon: '<i class="fa-solid fa-check"></i>',
        label: "Сохранить",
        callback: (html) => {
          saveAccent(html);
          FH.app?.render(true);
        }
      },
      cancel: {
        icon: '<i class="fa-solid fa-xmark"></i>',
        label: "Отмена"
      }
    },
    default: "save"
  }).render(true);
}


function installFlatyHubPointerHandler() {
  if (window.__flatyHubPointerHandlerInstalled) return;
  window.__flatyHubPointerHandlerInstalled = true;

  document.addEventListener("pointerdown", (event) => {
    const target = event.target?.closest?.("#flatyhub-app");
    if (!target) return;

    const page = event.target.closest?.("[data-fh-page]");
    if (page) {
      event.preventDefault();
      event.stopImmediatePropagation();
      FH.app._selectedPage = page.dataset.fhPage;
      void FH.app.render(true);
      return;
    }

    const refresh = event.target.closest?.("[data-fh-refresh]");
    if (refresh) {
      event.preventDefault();
      event.stopImmediatePropagation();
      void FH.app.render(true);
      return;
    }

    const hubSettingsButton = event.target.closest?.("[data-fh-hub-settings]");
    if (hubSettingsButton) {
      event.preventDefault();
      event.stopImmediatePropagation();
      FH.openSettings();
      return;
    }

    const keybindings = event.target.closest?.("[data-fh-keybindings]");
    if (keybindings) {
      event.preventDefault();
      event.stopImmediatePropagation();
      openFlatyHubKeyCapture();
      return;
    }

    const managerSettings = event.target.closest?.("[data-fh-manager-settings]");
    if (managerSettings) {
      event.preventDefault();
      event.stopImmediatePropagation();
      openFlatyHubManagerSettings();
      return;
    }

    const moduleSettings = event.target.closest?.("[data-fh-module-settings]");
    if (moduleSettings) {
      event.preventDefault();
      event.stopImmediatePropagation();
      const mod = FH.getModule(moduleSettings.dataset.fhModuleSettings);
      if (!mod) return;

      if (typeof mod.onSettings === "function") {
        try {
          mod.onSettings();
        } catch (error) {
          console.error(`FlatyHub | Error opening settings for "${mod.id}".`, error);
          ui.notifications.error(`FlatyHub: не удалось открыть настройки «${mod.name}».`);
        }
      } else {
        ui.notifications.info(`Модуль «${mod.name}» пока не предоставляет отдельную панель настроек.`);
      }
      return;
    }

    const moduleButton = event.target.closest?.("[data-fh-module]");
    if (moduleButton) {
      event.preventDefault();
      event.stopImmediatePropagation();
      const mod = FH.getModule(moduleButton.dataset.fhModule);
      if (!mod) return;

      if (typeof mod.onOpen === "function") {
        try {
          mod.onOpen();
        } catch (error) {
          console.error(`FlatyHub | Error opening module "${mod.id}".`, error);
          ui.notifications.error(`FlatyHub: не удалось открыть модуль «${mod.name}».`);
        }
      } else {
        ui.notifications.info(`Модуль «${mod.name}» пока не имеет собственного окна.`);
      }
    }
  }, true);
}

Hooks.once("init", () => {
  game.settings.register("flatyhub", "showWelcomeHint", {
    name: "Показывать подсказку при отсутствии модулей",
    hint: "Если включено, пустой центр управления показывает информационный блок.",
    scope: "client",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register("flatyhub", "accentColor", {
    name: "Цвет акцента FlatyHub",
    hint: "Основной цвет подсветки интерфейса FlatyHub.",
    scope: "client",
    config: true,
    type: String,
    default: "#ff8a24"
  });

  game.keybindings.register("flatyhub", "openHub", {
    name: "Открыть FlatyHub",
    hint: "Открывает центральный интерфейс управления модулями.",
    editable: [
      {
        key: "KeyH",
        modifiers: ["CONTROL", "SHIFT"]
      }
    ],
    onDown: () => {
      FH.open();
      return true;
    },
    restricted: false
  });

  game.flatyHub = FH;
});

Hooks.once("ready", () => {
  FH.version = game.modules.get("flatyhub")?.version ?? FH.version;
  installFlatyHubPointerHandler();
  console.info(`FlatyHub | Ready. Version ${FH.version}`);
  console.info("FlatyHub | API available at game.flatyHub");
});

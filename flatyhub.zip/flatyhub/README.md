# FlatyHub

Central management hub for future Flaty modules.

## Installation

1. Put the `flatyhub` folder into your Foundry `Data/modules/` directory.
2. Restart Foundry.
3. Enable **FlatyHub** in the world's Manage Modules menu.
4. Open **Configure Controls → Keybindings → FlatyHub** and assign your preferred hotkey.
5. Default hotkey: `Ctrl + Shift + H`.

## Future module API

A future module can register itself with:

```js
game.flatyHub.registerModule({
  id: "my-module",
  name: "My Module",
  description: "Module description",
  icon: "fa-solid fa-dragon",
  category: "Tools",
  version: "1.0.0",

  onOpen() {
    // Open module UI
  },

  onSettings() {
    // Optional settings UI
  }
});
```

The registration API is exposed as `game.flatyHub`.

## Notes

Version 1.2 fixes dashboard click handling by binding directly to the final rendered controls, keeps both close controls functional, and displays the real module version. The demo module was removed so the initial Hub starts empty.

The current version includes one temporary demo card so the Hub can be visually tested immediately.
When the first real Flaty module is connected, remove the `flatyhub-demo` registration block from `scripts/flatyhub.js`.


## Version 1.3
- Removed the duplicate internal close button.
- Hub version is read automatically from Foundry's installed module metadata.
- Dashboard controls use a single native event-delegation handler attached after rendering.
- Future module registrations continue to work through `game.flatyHub`.


## Version 1.4
- Reworked dashboard interaction to capture pointer events at the document level.
- Added a real module manager page.
- Added a settings center for FlatyHub and registered modules.
- Added an editable FlatyHub accent color.
- Future modules can expose their own settings through `onSettings()`.


## Version 1.5
- Renamed Overview to Главная.
- Simplified the home page: removed the Hub version card, connected-module section, refresh button, and bottom footer text.
- The Hotkey row in FlatyHub settings is now clickable and attempts to open Foundry's settings directly.
- Fixed the FlatyHub settings row so Foundry's default white button background no longer overrides the dark theme.


## Version 1.6
- Hotkey configuration is now handled directly inside FlatyHub.
- Clicking the Hotkey row opens a capture dialog asking for a key or key combination for opening FlatyHub.
- The captured binding is written through Foundry's `game.keybindings.set("flatyhub", "openHub", ...)`, so Configure Controls is updated automatically.
- The current shortcut is displayed in the FlatyHub settings row.
